import os
import pymysql
import random
import openpyxl
from openpyxl import load_workbook
import baostock as bs
import pandas as pd


def sh_stock_create(filename):

    # 加载excel文件
    print("加载文件"+ filename)
    wb = load_workbook(filename)
    # 获取所有工作表
    print("解析文件"+ filename)
    names = wb.sheetnames
    # 获取第一个工作表
    sheet = wb[names[0]]
    # 获取最大行数
    maxRow = sheet.max_row
    # 获取最大列数
    maxColumn = sheet.max_column
    # 解析excel文件
    unit_code_list = []
    for row_num in range(2,maxRow+1):
        unit_code = sheet.cell(row=row_num, column=1).value
        str_unit_code = str(unit_code)
        unit_name = sheet.cell(row=row_num, column=2).value
        unit_name = unit_name.strip()
        market_time = sheet.cell(row=row_num, column=5).value
        market_time = market_time.strip()

        unit_code_list.append([unit_code,unit_name,market_time])
    #
    print("解析完成"+filename) 
             
    # 创建数据库
    print("开始创建数据库")              
    con = pymysql.connect(host='127.0.0.1', user='root', passwd="tjj31415")
    # 建立游标
    cur = con.cursor()
    sql = 'create database if not exists sh_stock character set gbk'
    cur.execute(sql)    
    print("创建数据库完成")
    # 关闭游标
    cur.close()
    # 关闭连接
    con.close()
    # 连接数据库
    con = pymysql.connect(host='127.0.0.1', user='root', passwd="tjj31415", db='sh_stock')
    # 建立游标
    cur = con.cursor()
      
    # 创建统计表
    tbname = 'shstatistics'
    tbitem = ('code INT primary key  not null,'
              'name VARCHAR(10),'              
              'base_price FLOAT,base_time DATETIME,'
              'check_price FLOAT,check_time DATETIME,'
              'low_price FLOAT,low_time DATETIME,'
              'high_price FLOAT,high_time DATETIME')
    sql = 'create table if not exists ' + tbname + '(' + tbitem + ')'
    cur.execute(sql)
    print("创建表" + tbname + '完成')
    
    # 创建股票表
    for i in range(len(unit_code_list)):
        tbname = 'sh' + str(unit_code_list[i][0])
        tbitem = ('date DATE,'                  
                  'open_price TEXT,'
                  'high_price TEXT,'
                  'low_price TEXT,'
                  'close_price TEXT,'
                  'volume TEXT,'
                  'amount TEXT,'
                  'pctChg TEXT')
        sql = 'create table if not exists ' + tbname + '(' + tbitem + ')'                
        cur.execute(sql)
        print("创建表" + tbname + '完成')
    
    # 关闭游标
    cur.close()
    # 提交事务
    con.commit()
    # 关闭连接
    con.close()
    #
    print("创建数据库完成")

def sh_stock_update(filename):

    # 加载excel文件    
    wb = load_workbook(filename)
    # 获取所有工作表
    names = wb.sheetnames
    # 获取第一个工作表
    sheet = wb[names[0]]
    # 获取最大行数
    maxRow = sheet.max_row
    # 获取最大列数
    maxColumn = sheet.max_column
    # 解析excel文件
    unit_code_list = []
    for row_num in range(2,maxRow+1):
        unit_code = sheet.cell(row=row_num, column=1).value
        str_unit_code = str(unit_code)
        unit_name = sheet.cell(row=row_num, column=2).value
        unit_name = unit_name.strip()
        market_time = sheet.cell(row=row_num, column=5).value
        market_time = market_time.strip()

        unit_code_list.append([unit_code,unit_name,market_time])
    #
             
    # 连接数据库
    con = pymysql.connect(host='127.0.0.1', user='root', passwd="tjj31415", db='sh_stock')
    # 建立游标
    cur = con.cursor()

    #### 登录系统 ####
    print("login BaoSock")    
    lg = bs.login()
    # 显示登录返回信息
    #print('login respond error_code:'+lg.error_code)
    #print('login respond  error_msg:'+lg.error_msg)

    #### 遍历各上市公司代码,获取历史日K线数据 ####   
    for i in range(len(unit_code_list)):
        tbname = 'sh.' + str(unit_code_list[i][0])        
        rs = bs.query_history_k_data_plus(tbname,"date,code,open,high,low,close,volume,amount,pctChg",start_date='2020-02-03', end_date='2020-03-31',frequency="d", adjustflag="3")        
        data_list = []
        while (rs.error_code == '0') & rs.next():
            data_list.append(rs.get_row_data())

        tbname2 = 'sh' + str(unit_code_list[i][0])
        print("正在更新"+tbname2,end="")
        for j in range(len(data_list)):            
            sql = 'insert into ' + tbname2 + '(date,open_price,high_price,low_price,close_price,volume,amount,pctChg) values(%s,%s,%s,%s,%s,%s,%s,%s)'            
            cur.execute(sql,(data_list[j][0],data_list[j][2],data_list[j][3],data_list[j][4],data_list[j][5],data_list[j][6],data_list[j][7],data_list[j][8]))
            con.commit()        
        print(",更新完成")

    #### 登出系统 ####
    print("logout BaoSock")
    bs.logout()

    # 关闭游标
    cur.close()
    # 提交事务
    con.commit()
    # 关闭连接
    con.close()
    
def sz_stock_create(filename):

    # 加载excel文件
    print("加载文件"+ filename)
    wb = load_workbook(filename)
    # 获取所有工作表
    print("解析文件"+ filename)
    names = wb.sheetnames
    # 获取第一个工作表
    sheet = wb[names[0]]
    # 获取最大行数
    maxRow = sheet.max_row
    # 获取最大列数
    maxColumn = sheet.max_column
    # 解析excel文件
    unit_code_list = []
    for row_num in range(2,maxRow+1):
        unit_code = sheet.cell(row=row_num, column=6).value        
        #str_unit_code = str(unit_code)
        unit_name = sheet.cell(row=row_num, column=7).value
        unit_name = unit_name.strip()
        market_time = sheet.cell(row=row_num, column=8).value
        market_time = market_time.strip()

        if(len(unit_name) == 0 ):
            continue
        #print(unit_code,':',unit_name)
        unit_code_list.append([unit_code,unit_name,market_time])
    #
    print("解析完成"+filename) 

    # 创建数据库
    print("开始创建数据库")              
    con = pymysql.connect(host='127.0.0.1', user='root', passwd="tjj31415")
    # 建立游标
    cur = con.cursor()
    sql = 'create database if not exists sz_stock character set gbk'
    cur.execute(sql)    
    print("创建数据库完成")
    # 关闭游标
    cur.close()
    # 关闭连接
    con.close()
    # 连接数据库
    con = pymysql.connect(host='127.0.0.1', user='root', passwd="tjj31415", db='sz_stock')
    # 建立游标
    cur = con.cursor()
      
    # 创建统计表
    tbname = 'szstatistics'
    tbitem = ('code INT primary key  not null,'
              'name VARCHAR(10),'              
              'base_price FLOAT,base_time DATETIME,'
              'check_price FLOAT,check_time DATETIME,'
              'low_price FLOAT,low_time DATETIME,'
              'high_price FLOAT,high_time DATETIME')
    sql = 'create table if not exists ' + tbname + '(' + tbitem + ')'    
    cur.execute(sql)
    print("创建表" + tbname)
    
    # 创建股票表
    for i in range(len(unit_code_list)):
        tbname = 'sz' + str(unit_code_list[i][0])
        tbitem = ('date DATE,'                  
                  'open_price TEXT,'
                  'high_price TEXT,'
                  'low_price TEXT,'
                  'close_price TEXT,'
                  'volume TEXT,'
                  'amount TEXT,'
                  'pctChg TEXT')
        sql = 'create table if not exists ' + tbname + '(' + tbitem + ')'                
        cur.execute(sql)
        print("创建表" + tbname)
    
    # 关闭游标
    cur.close()
    # 提交事务
    con.commit()
    # 关闭连接
    con.close()
    #
    print("创建数据库完成")

def sz_stock_update(filename):

    # 加载excel文件
    print("加载文件"+ filename)
    wb = load_workbook(filename)
    # 获取所有工作表
    print("解析文件"+ filename)
    names = wb.sheetnames
    # 获取第一个工作表
    sheet = wb[names[0]]
    # 获取最大行数
    maxRow = sheet.max_row
    # 获取最大列数
    maxColumn = sheet.max_column
    # 解析excel文件
    unit_code_list = []
    for row_num in range(2,maxRow+1):
        unit_code = sheet.cell(row=row_num, column=6).value        
        #str_unit_code = str(unit_code)
        unit_name = sheet.cell(row=row_num, column=7).value
        unit_name = unit_name.strip()
        market_time = sheet.cell(row=row_num, column=8).value
        market_time = market_time.strip()

        if(len(unit_name) == 0 ):
            continue
        #print(unit_code,':',unit_name)
        unit_code_list.append([unit_code,unit_name,market_time])
    #
    print("解析完成"+filename)
    
     # 连接数据库
    con = pymysql.connect(host='127.0.0.1', user='root', passwd="tjj31415", db='sz_stock')
    # 建立游标
    cur = con.cursor()

    #### 登录系统 ####
    print("login BaoSock")    
    lg = bs.login()
    # 显示登录返回信息
    #print('login respond error_code:'+lg.error_code)
    #print('login respond  error_msg:'+lg.error_msg)

    #### 遍历各上市公司代码,获取历史日K线数据 ####   
    for i in range(len(unit_code_list)):
        tbname = 'sz.' + str(unit_code_list[i][0])        
        rs = bs.query_history_k_data_plus(tbname,"date,code,open,high,low,close,volume,amount,pctChg",start_date='2020-02-03', end_date='2020-03-31',frequency="d", adjustflag="3")        
        data_list = []
        while (rs.error_code == '0') & rs.next():
            data_list.append(rs.get_row_data())

        tbname2 = 'sz' + str(unit_code_list[i][0])
        print("正在更新"+tbname2,end="")
        for j in range(len(data_list)):            
            sql = 'insert into ' + tbname2 + '(date,open_price,high_price,low_price,close_price,volume,amount,pctChg) values(%s,%s,%s,%s,%s,%s,%s,%s)'            
            cur.execute(sql,(data_list[j][0],data_list[j][2],data_list[j][3],data_list[j][4],data_list[j][5],data_list[j][6],data_list[j][7],data_list[j][8]))
            con.commit()        
        print(",更新完成")

    #### 登出系统 ####
    print("logout BaoSock")
    bs.logout()

    # 关闭游标
    cur.close()
    # 提交事务
    con.commit()
    # 关闭连接
    con.close()
    
    
if __name__ == '__main__':

    print('创建上交所数据库')
    stockfile = 'sh-stock.xlsx'
    sh_stock_create(stockfile)
    print('更新上交所数据库')
    sh_stock_update(stockfile)
    
    print('创建深交所数据库')
    stockfile = 'sz-stock.xlsx'
    sz_stock_create(stockfile)
    print('更新深交所数据库')
    sz_stock_update(stockfile)
    

